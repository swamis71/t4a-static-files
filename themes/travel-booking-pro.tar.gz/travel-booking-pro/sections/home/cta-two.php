<?php
/**
 * CTA Two Section
 * 
 * @package Travel_Booking_Pro
*/

if( is_active_sidebar( 'cta-two' ) ){ ?>
<!-- CTA two -->
	<div id="cta-two-section" class="cta-section">
		<div class="container">
			<?php dynamic_sidebar( 'cta-two' ); ?>
		</div>
	</div>
<?php }